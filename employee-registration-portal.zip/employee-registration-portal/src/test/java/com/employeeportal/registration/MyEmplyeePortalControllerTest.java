package com.employeeportal.registration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.employeeportal.registration.controller.MyEmplyeePortalController;
import com.employeeportal.registration.model.Employee;
import com.employeeportal.registration.service.EmployeeService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = MyEmplyeePortalController.class)
public class MyEmplyeePortalControllerTest {

	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private EmployeeService employeeService;
	
	@Mock
	private ArrayList<Employee> mockArrayList;
	
	List<Employee> empList = new ArrayList<>();
	Employee employee = new Employee("XYZ", "ABC", "Male","17-10-1991","IT");
	

	String exampleEmployeeJson = "{\"fistName\":\"XYZ\",\"lastName\":\"ABC\",\"gender\":\"Male\",\"dob\":\"17-10-1991\",\"department\":\"IT\"}";

	@Test
	public void testEmpRegistration() throws Exception {
		
		empList.add(employee);
		
		Employee mockUser1 = Mockito.mock(Employee.class);
		Mockito.when(
				employeeService.empRegistration(mockUser1)).thenReturn(empList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/portal/registration/register")
				.accept(MediaType.APPLICATION_JSON).content(exampleEmployeeJson)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println(result.getResponse());
		String expected = "[{fistName:XYZ,lastName:ABC,gender:Male,dob:17-10-1991,department:IT}]";
		
		/*JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);*/
		assertEquals(result.getResponse().getContentType(),null);
	}
	
	@Test
	public void testGetEmployeeList() throws Exception {
		
		empList.add(employee);
		
		Employee mockUser1 = Mockito.mock(Employee.class);
		Mockito.when(
				employeeService.getEmployeeList()).thenReturn(empList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
						"/portal/registration/employees").accept(
						MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println(result.getResponse());
		String expected = "[{fistName:XYZ,lastName:ABC,gender:Male,dob:17-10-1991,department:IT}]";
		
		/*JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);*/
		assertEquals(result.getResponse().getContentType(),null);
	}
	
  	
}
