package com.employeeportal.registration.service;

import java.util.List;

import com.employeeportal.registration.model.Employee;

public interface EmployeeService {
	
	public List<Employee> getEmployeeList();
	public List<Employee> empRegistration(Employee emp);

}
