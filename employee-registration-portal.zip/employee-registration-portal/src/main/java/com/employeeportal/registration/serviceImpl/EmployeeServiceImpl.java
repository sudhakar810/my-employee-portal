package com.employeeportal.registration.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.employeeportal.registration.model.Employee;
import com.employeeportal.registration.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	
	ArrayList<Employee> registredEmp = new ArrayList<>();
	@Override
	public List<Employee> getEmployeeList() {
		registredEmp.sort((o1, o2) -> o1.getFirstName().compareTo(o2.getFirstName()));
		return registredEmp;
	}

	@Override
	public List<Employee> empRegistration(Employee emp) {
		registredEmp.add(emp);
		return registredEmp;
	}
	
	

}
