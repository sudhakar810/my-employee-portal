package com.employeeportal.registration.common;

public class MyEmplyooPrtalURIConstants {
	 public static final String REGISTER = "/register";
	 public static final String ALL_EMPLOYEES_LIST = "/employees";
}

