package com.employeeportal.registration.controller;

import static com.employeeportal.registration.common.MyEmplyooPrtalURIConstants.*;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.employeeportal.registration.model.Employee;
import com.employeeportal.registration.service.EmployeeService;

@RestController
@RequestMapping("registration")
public class MyEmplyeePortalController {
	
	@Autowired
	EmployeeService empService;
	
	List<Employee> registredEmp = new ArrayList<>();
	@CrossOrigin(origins="http://localhost:4200",maxAge = 3600)
    @PostMapping(value = REGISTER)
    public Boolean empRegistration(@RequestBody Employee employee) throws ParseException {
		
		registredEmp = empService.empRegistration(employee);
    	if(registredEmp.size()>0) {
    		return true;
    	}
    	else 
    		return false;
    }
	
	@CrossOrigin(origins="http://localhost:4200",maxAge = 3600)
	 @GetMapping(value=ALL_EMPLOYEES_LIST)
	    public List<Employee> getEmployeeList() {
		
		registredEmp = empService.getEmployeeList();
		return registredEmp;
	    
	    }

	

}


