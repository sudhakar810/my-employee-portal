import { Component } from '@angular/core';
import { Observable } from 'rxjs';


import { Employee } from './Employee';
import { EmployeeService } from './Employee.service';

@Component({
  selector: 'employee-portal',
  templateUrl: './Employee-portal.component.html',
  styleUrls: ['./Employee-portal.component.css'],
  providers: [EmployeeService]
})

export class EmployeePortalComponent {
  
 /* Instance variable */
 first_name:string;
 last_name:string;
 gender:string;
 dob:string;
 department:string

  constructor(private employeeService: EmployeeService) {

  }

  fillDetails(){
    alert("Please fill all the details ..");
  }

  
  registerEmployee(first_name:string,last_name:string,gender:string,dob:string,department:string){
    if(gender && gender.toUpperCase() !== "MALE" && gender.toUpperCase() !== "FEMALE"){
      alert("please enter gender Male/Female only");
    }
    else if(first_name&&last_name&&gender&&dob&&department){
      let emp = new Employee();
    emp.firstName = first_name;
    emp.lastName = last_name;
    emp.gender = gender;
    emp.dob = dob;
    emp.department = department;
    this.employeeService.registerEmployee(emp).subscribe(
      response => {
        if(response==true){
          alert("Registration successfully ..");
          this.first_name="";
           this.last_name="";
           this.gender="";
           this.dob="";
           this.department=""
        }
      },
      err => console.log(err)
    );
    } else {
       this.fillDetails();
    }
    
  }
  
  allemployeeList=<any>[];
  getEmployees() {
    this.employeeService.getEmployees().subscribe(
      response => {
        this.allemployeeList = response;
        if(this.allemployeeList.length==0) {
          this.allemployeeList = [];
        }
        console.log(response);
      },
      err => console.log(err)
    );
  }

}