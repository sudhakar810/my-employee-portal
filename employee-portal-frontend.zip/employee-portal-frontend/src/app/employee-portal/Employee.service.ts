import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Employee } from './employee';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
@Injectable()
export class EmployeeService {

    baseUrl:string = "http://localhost:8081";
    constructor(private httpClient : HttpClient) { }
  
    registerEmployee(emp:Employee){
        
        let empRegURL =this.baseUrl +'/portal/registration/register';
        const body = JSON.stringify(emp);
        return this.httpClient.post(empRegURL, body, httpOptions);
}

getEmployees(){
        return this.httpClient.get(this.baseUrl + '/portal/registration/employees');
    }
}