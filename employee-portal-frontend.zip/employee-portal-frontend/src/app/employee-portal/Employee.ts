

export class Employee {
    
    firstName: string;
    lastName: string;
    gender: string;
    dob:string;
    department:string;
    constructor() { }
}